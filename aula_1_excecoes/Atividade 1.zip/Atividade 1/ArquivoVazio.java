public class ArquivoVazio extends Exception{
    public ArquivoVazio(){
        super("Arquivo vazio!");
    }
}
